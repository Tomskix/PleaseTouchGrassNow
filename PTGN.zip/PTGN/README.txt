Sick you downloaded PTGN or Please touch grass now
Dm me (Tomski#0001) For Sourcecode, problems, or suggestions.
Before you ask fake ip doesnt hide you completely :kys:
Also dont ask me about custom port im working on it jeez (20 dms already)

Also run PythonApplication.exe for thing i cant rename it :pensive: